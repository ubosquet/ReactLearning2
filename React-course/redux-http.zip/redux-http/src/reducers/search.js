const initialState = {

};

const reducer = (state = initialState, action) => {

};

export default reducer;